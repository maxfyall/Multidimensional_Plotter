Z = magic(5);
b = bar3h(Z);
colorbar

for k = 1:length(b)
    zdata = b(k).ZData;
    b(k).CData = zdata;
    b(k).FaceColor = 'interp';
end

%x = linspace(0,2*pi,100);
%y = sin(x);
%plot(x,y)